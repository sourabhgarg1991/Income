package com.income.core.service;

import com.income.core.api.Currency;
import com.income.core.api.Income;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class AverageIncomeTest {
  AverageIncome averageIncome = new AverageIncome();
  List<Income> incomes;

  @Test
  public void getAverageIncomeWithValidValues(){
    incomes = new ArrayList<>();
    List<String> expectedOutput = new ArrayList<>();
    incomes.add(new Income("india", "delhi", "M", Currency.INR, 10000));
    incomes.add(new Income("india", "mumbai", "M", Currency.INR, 30000));
    List<String> actualOutput = averageIncome.getAverageIncome(incomes);
    expectedOutput.add("india,M,303.03");
    Assert.assertEquals(expectedOutput, actualOutput);
    }

  @Test
  public void getAverageIncomeWithNullValues(){
    incomes = new ArrayList<>();
    List<String> expectedOutput = new ArrayList<>();
    List<String> actualOutput = averageIncome.getAverageIncome(incomes);
    Assert.assertEquals(expectedOutput, actualOutput);
  }
}
