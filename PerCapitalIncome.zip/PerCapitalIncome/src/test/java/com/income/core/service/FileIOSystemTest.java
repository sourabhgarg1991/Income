package com.income.core.service;

import com.income.core.api.Currency;
import com.income.core.api.Income;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class FileIOSystemTest {
  FileIOSystem fileIOSystem = new FileIOSystem();

  @Test
  public void getIncomeFromCSVWithValidValues(){
    List<Income> actual = fileIOSystem.getIncomeFromCSV("C:\\Users\\sourabh.garg\\Desktop\\cross-ride-java\\PerCapitalIncome\\src\\test\\resources\\Valid_Input.csv");
    List<Income> expected = new ArrayList<>();
    expected.add(new Income("IND", "Delhi", "M", Currency.INR, 30000));
    Assert.assertEquals(expected.size(), actual.size());
    Assert.assertEquals(expected.get(0).getAvgIncome(), actual.get(0).getAvgIncome(), 0);
    Assert.assertEquals(expected.get(0).getCountry(), actual.get(0).getCountry());
    Assert.assertEquals(expected.get(0).getCurrency(), actual.get(0).getCurrency());
    Assert.assertEquals(expected.get(0).getGender(), actual.get(0).getGender());
    Assert.assertEquals(expected.get(0).getCity(), actual.get(0).getCity());
  }

  @Test
  public void getIncomeFromCSVNullValues(){
    List<Income> actual = fileIOSystem.getIncomeFromCSV("C:\\Users\\sourabh.garg\\Desktop\\cross-ride-java\\PerCapitalIncome\\src\\test\\resources\\Null_Input.csv");
    List<Income> expected = new ArrayList<>();
    Assert.assertEquals(expected, actual);
  }
}