package com.income.core.service;

import com.income.core.api.Income;
import com.income.core.dao.CsvFileDao;
import com.income.core.dao.ExcelFileDao;

import java.util.List;

public class FileIOSystem {

  CsvFileDao csvFileReader;
  ExcelFileDao excelFileReader;

  public List<Income> getIncomeFromCSV(String path) {
    csvFileReader = new CsvFileDao();
    return csvFileReader.readIncome(path);
  }

  public void putAverageIncomeIntoCSV(final String path, final List<String> sortedAverageIncome) {
    csvFileReader = new CsvFileDao();
    csvFileReader.writeIncome(path, sortedAverageIncome);
  }

  //Dummy method. Need to write code in dao respect to this method.
  public List<Income> getIncomeFromExcel(String path) {
    excelFileReader = new ExcelFileDao();
    return excelFileReader.readIncome(path);
  }
}
