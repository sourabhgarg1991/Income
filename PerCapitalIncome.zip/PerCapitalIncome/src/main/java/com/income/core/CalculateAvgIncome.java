package com.income.core;

import static com.income.core.constant.IncomeConstant.INPUT_FILE_PATH;
import static com.income.core.constant.IncomeConstant.OUTPUT_FILE_PATH;

import com.income.core.api.Income;
import com.income.core.service.AverageIncome;
import com.income.core.service.FileIOSystem;

import java.util.List;

public class CalculateAvgIncome {

  public static void main(String[] args) {
    FileIOSystem fileIO = new FileIOSystem();
    List<Income> incomes = fileIO.getIncomeFromCSV(INPUT_FILE_PATH);

    AverageIncome averageIncome = new AverageIncome();
    List<String> sortedAverageIncome = averageIncome.getAverageIncome(incomes);

    fileIO.putAverageIncomeIntoCSV(OUTPUT_FILE_PATH, sortedAverageIncome);
  }
}

