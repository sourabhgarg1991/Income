package com.income.core.dao;

import com.income.core.api.Income;
import com.income.core.impl.FileReaderIMPL;

import java.util.List;

public class ExcelFileDao implements FileReaderIMPL {

  public List<Income> readIncome(final String path) {
    //Implement code to read excel and get Income
    return null;
  }
}
