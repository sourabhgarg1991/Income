package com.income.core.dao;

import com.income.core.api.Currency;
import com.income.core.api.Income;
import com.income.core.constant.IncomeConstant;
import com.income.core.impl.FileReaderIMPL;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CsvFileDao implements FileReaderIMPL {

  BufferedReader br = null;
  String line = "";
  List<Income> incomeList;

  public List<Income> readIncome(final String path) {
    incomeList = new ArrayList<Income>();
    try {
      br = new BufferedReader(new FileReader(path));
      //Remove header while reading records
      br.readLine();
      while ((line = br.readLine()) != null) {
        // use comma as separator
        String[] income = line.split(IncomeConstant.CSV_DELIM);
        incomeList.add(parseCSV(income));
      }
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      if (br != null) {
        try {
          br.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
    return incomeList;
  }

  private Income parseCSV(String[] income) {
    String country = income[IncomeConstant.COUNTRY_INDEX];
    String city = income[IncomeConstant.CITY_INDEX];
    String gender = income[IncomeConstant.GENDER_INDEX];
    String currency = income[IncomeConstant.CURRENCY_INDEX];
    String avgIncome = income[IncomeConstant.INCOME_INDEX];

    return new Income(country, city, gender, Currency.valueOf(currency), Double.valueOf(avgIncome));
  }

  public void writeIncome(final String path, final List<String> sortedAverageIncome) {
    File file = new File(path);
    try {
      FileWriter writer = new FileWriter(file);

      //Added header
      String header = "Country, Gender, AverageIncome(in USD)";
      writer.append(header);

      //Added Records
      for (String income : sortedAverageIncome) {
        writer.append("\n" + income);
      }
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
