package com.income.core.impl;

import com.income.core.api.Income;

import java.util.List;

public interface FileReaderIMPL {
  List<Income> readIncome(String path);
}
