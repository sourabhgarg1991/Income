package com.income.core.service;

import static java.util.stream.Collectors.*;

import com.income.core.api.Currency;
import com.income.core.api.Income;
import com.income.core.constant.IncomeConstant;

import java.text.DecimalFormat;
import java.util.*;
import java.util.Map.Entry;

public class AverageIncome {

  List<Income> incomeList;
  private static DecimalFormat format = new DecimalFormat(".##");

  public List<String> getAverageIncome(List<Income> incomes) {
    incomes = convertCurrencyToUS(incomes);
    Map<String, Map<String, Double>> averageIncome = incomes.stream()
                                                            .collect(groupingBy(Income::getCountry,
                                                                                groupingBy(Income::getGender,
                                                                                           averagingDouble(
                                                                                               Income::getAvgIncome))))
                                                            .entrySet()
                                                            .stream()
                                                            .sorted(Entry.comparingByKey())
                                                            .collect(toMap(Entry::getKey, Entry::getValue,
                                                                           (m1, m2) -> m1,
                                                                           HashMap::new));

    return convertMapToString(averageIncome);
  }

  private List<String> convertMapToString(
      final Map<String, Map<String, Double>> avgGenderIncomeByCountry) {
    List convertedValues = new ArrayList();
    for (String country : avgGenderIncomeByCountry.keySet()) {
      for (String gender : avgGenderIncomeByCountry.get(country).keySet()) {
        convertedValues.add(getStringValue(country, gender, avgGenderIncomeByCountry.get(country).get(gender)));
      }
    }
    return convertedValues;
  }

  private String getStringValue(String country, String gender, Double income) {
    return country + "," + gender + "," + format.format(income);
  }

  private List<Income> convertCurrencyToUS(List<Income> incomes) {
    incomeList = new ArrayList<Income>();
    for (Income income : incomes) {
      Currency currency = income.getCurrency();
      switch (currency) {
        case INR:
          income.setAvgIncome(income.getAvgIncome() / IncomeConstant.INR_RATE);
          income.setCurrency(Currency.USD);
          break;

        case SGP:
          income.setAvgIncome(income.getAvgIncome() / IncomeConstant.SGP_RATE);
          income.setCurrency(Currency.USD);
          break;

        case GBP:
          income.setAvgIncome(income.getAvgIncome() / IncomeConstant.GBP_RATE);
          income.setCurrency(Currency.USD);
          break;
      }
      incomeList.add(income);
    }
    return incomeList;
  }
}
