package com.income.core.constant;

public class IncomeConstant {

  public static final int INCOME_INDEX = 4;
  public static final int CURRENCY_INDEX = 3;
  public static final int GENDER_INDEX = 2;
  public static final int CITY_INDEX = 1;
  public static final int COUNTRY_INDEX = 0;
  public static final String CSV_DELIM = ",";
  public static final double INR_RATE = 66;
  public static final double USD_RATE = 1;
  public static final double GBP_RATE = 1.74;
  public static final double SGP_RATE = 1.34;
  public static final String INPUT_FILE_PATH =
      "C:\\Users\\sourabh.garg\\Desktop\\cross-ride-java\\PerCapitalIncome\\src\\main\\resources\\Sample_Input.csv";
  public static final String OUTPUT_FILE_PATH =
      "C:\\Users\\sourabh.garg\\Desktop\\cross-ride-java\\PerCapitalIncome\\src\\main\\resources\\Sample_Output.csv";
}
