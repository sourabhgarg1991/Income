package com.income.core.api;

public enum Currency {
    USD, INR, GBP, SGP;
}
